<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php
	$fname="files/5.txt";
	$fp = fopen($fname, 'r');
	$str=fread($fp,filesize($fname));
	print "ALL CONTENTS".$str."<br><br><br>";
	print str_replace("\n","<br>",$str)."<br><br>---";
	
	fseek($fp,0);
	
	$contents = "";
	do 
	{
	    $data = fread($fp, 10);
	    if (strlen($data) == 0) {
	        break;
	    }
	    $contents .= $data;
	} while (true);
	print str_replace("\n","<br>",$contents);
	fclose($fp);
?>
</body>
</html>

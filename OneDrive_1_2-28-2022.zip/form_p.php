<?php 
	if(isset($_POST['submit']))
	{	
	print "You typed username: $_POST[username]<br>";
	print "You typed password: $_POST[password]<br>";
	}
	else if(isset($_POST['submit1']) && isset($_POST['text1']))
	{
		if($_POST['text1']=="page1")
		{
			//echo "abc";
			header("Location: page1.php");
		}
		else if($_POST['text1']=="page2")
			header("Location: page2.php");
		else
			echo "invalid input";
			
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
  <title>Process form Info</title>
</head><body>
<br>
<?php	
	echo $_SERVER["PHP_SELF"]."<br>";
	echo $_SERVER["SERVER_ADDR"]."<br>";
	echo $_SERVER["SERVER_NAME"]."<br>";
	echo $_SERVER["QUERY_STRING"]."<br>";
	echo $_SERVER["REQUEST_METHOD"]."<br>";
	echo $_SERVER["REMOTE_ADDR"]."<br>";	
	echo $_SERVER["HTTP_REFERER"]."<br>";	

?>
</body></html>

<?php
	if(isset($_POST["s1"]))
	{
		echo $_POST["t1"];

	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php
if ($handle = opendir('files')) {
    echo "Directory handle: $handle <br><br>";
    echo "Files: <br><br>";

    /* This is the correct way to loop over the directory. */
while (false !== ($file = readdir($handle))) { 
		if($file!="." && $file!="..")
        {            
        if(is_dir("files/".$file))
		{
            echo $file."<br>";
        }
        else
        {
		?>
      <?php echo $file;?>&nbsp;&nbsp; 
<a href="file_dl.php?fname=<?php echo $file;?>">
    <?php echo $file; ?></a>&nbsp;&nbsp; 

    <br>
		<?php
		}
    }
    }
    closedir($handle); 
}
?>
</body>
</html>
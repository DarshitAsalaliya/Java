<?php
	$fpath="files/".$_GET["fname"];	
	$fname=$_GET["fname"];
	
	//$fname="files/6th-2012.doc";
	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream'); //text/html image/jpg  MIME type
	header('Content-Length: ' . filesize($fpath));
	header("Content-Disposition: attachment; filename=".$fname);

	$fp=fopen($fpath,"rb");
	//$str=fread($fp,filesize($fpath));
	//echo $str;
	fpassthru($fp);
	fclose($fp);
	//exit();
/*
default MIME o/p type: text/plain or text/html
other o/p types:
image/jpeg,image/gif
video/mpeg, application/msexcel(pdf,msword etc.)
o/p type for all types of files: application/octet-stream */
?>
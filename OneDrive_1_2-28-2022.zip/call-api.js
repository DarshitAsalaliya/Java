var express = require('express');
var app = express();
var request = require('request');

//request(URL or options,callback(error, response, body){  })

//Call books API from another node app
app.get("/",function(req,res){
	var options = { 
		method: 'GET',
	  	url: 'http://localhost:8000/books'
	  	//url: 'http://localhost/user_module/mysqli-rest1.php'
	 };
	 //request(options,(err,res,body)=>{})
	request(options, function (error, response, body) 
	{
	  if (error) throw new Error(error);

    console.log(body);
    res.status(200).send(body);
	});
})

// Call third party URL and obtain response
app.get("/google",function(req,res){
  request('http://www.google.com', function (error, response, body) {
  if (!error && response.statusCode == 200) {
    res.send(body);
  }
})
})

//call third party Weather API with key
app.get("/weather",function(req,res){
	let apiKey = '';
	let city = 'surat';
	
	let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`

	request(url, function (error, response, body) {
	  if(error){
	    console.log('error:', error);
	    res.send(error);
	  } else {
	  	var weather = JSON.parse(body)
	  	var t=`  Temperature ${weather.main.temp} degrees in ${weather.name}!`;
	    //console.log('body:', body +t );
	    res.send(body+"<br><br>"+t);
	  }
	});
})
app.listen(8001);
<html>
<body>
	<?php
		if(isset($_GET["s1"]) && isset($_GET["s1"]))
			echo $_GET["t1"];
	?>
	<form name="f1" method="get" action="f1.php">
		Enter name: <input type="text" name="t1">
		<input type="submit" name="s1">
	</form>
</body>
</html>
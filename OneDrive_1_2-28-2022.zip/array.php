<html>
	<body>
<?php

$datedisplay=date("Y/m/d");
echo $datedisplay."<br><br>";

function sum($a,$b)
{
	global $c;
	$c=$a+$b;
}
$c=0;
sum ( 5 , 1 ); 
print $c."<br><br>";


?>

		<table border="1">
			<?php
				for($i=1;$i<=10;$i+=2)
				{
					?>
						<tr><td><?php echo $i;?></td></tr>
					<?php					
				}
			?>
		</table>

	</body>
</html>
<?php
	echo "Hello!!<br>";
	$a=array("a"=>1,2,3,4,5);
	print_r($a);
	foreach($a as $k=>$v)
		echo "<br>".$k."=>".$v;
?>
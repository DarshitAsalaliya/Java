<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
  
  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
  <title>cookie.php</title>

  
</head><body style="color: rgb(0, 0, 0); background-color: rgb(255, 255, 255);" alink="#000088" link="#0000ff" vlink="#ff0000">
<br><br><br>
<?php if(isset($_COOKIE["uname"]))
{
	echo "Welcome ".$_COOKIE["uname"];
}
	else
	{
?>
<form method="post" action="cookie_p.php" name="cookie_form"><br>

Enter Your Name:<input name="uname"><br>
  <input value="Submit" type="submit"><br>
</form>
<?php }	?>
</body></html>

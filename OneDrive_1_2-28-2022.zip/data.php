<p>Hello111</p>
<h2>Try AJAX with jQuery.</h2>
<p id="p1">Paragraph1</p>

<?php echo "Hello"; ?>
<!DOCTYPE HTML >
<html>
<head>
<title>Download File</title>
</head>

<body>
<a href="file_dl.php?fname=5.txt">Download file</a>
</body>
</html>
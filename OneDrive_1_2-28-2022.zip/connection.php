<?php
$con = mysqli_connect("localhost", "root", "","student_db")
	or die("Could not connect : " .  mysql_error());
	
			
?>
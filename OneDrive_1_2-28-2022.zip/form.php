<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form name="userForm" method="post" action="form_p.php">
  Enter a user name: <input type="text" name="username" size="20"><br>
  Enter a password: <input type="password" name="password" size="20">
  <input type="submit" name="submit" value="Send">
</form>
<br><br>
<form name="form1" method="post" action="form_p.php">
  Enter page name: <input type="text" name="text1" size="20">
  <input type="submit" name="submit1" value="OK">
</form>
</body>
</html>

<?php 
	setcookie('uname',$_POST['uname']);
	echo "Cookie is set";
?>